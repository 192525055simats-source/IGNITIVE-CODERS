const router = require('express').Router();
const { getAll } = require('../controllers/usersController');
router.get('/', getAll);
module.exports = router;
