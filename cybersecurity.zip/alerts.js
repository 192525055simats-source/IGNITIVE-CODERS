const router = require('express').Router();
const { getAll } = require('../controllers/alertsController');
router.get('/', getAll);
module.exports = router;
