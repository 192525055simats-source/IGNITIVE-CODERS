// Mock in-memory data store.
// Replace with MongoDB / PostgreSQL in production.

const bcrypt = require('bcryptjs');

const USERS = [
  { id: 'u1', name: 'SP Rajesh Kumar', email: 'admin@cybershield.gov.in', password: bcrypt.hashSync('admin123', 10), role: 'admin', district: 'Chennai', status: 'Active' },
  { id: 'u2', name: 'Inspector Meena', email: 'analyst@cybershield.gov.in', password: bcrypt.hashSync('analyst123', 10), role: 'analyst', district: 'Chennai', status: 'Active' },
  { id: 'u3', name: 'SI Prakash', email: 'officer@cybershield.gov.in', password: bcrypt.hashSync('officer123', 10), role: 'officer', district: 'Chennai', status: 'Active' },
];

const COMPLAINTS = [
  { id: 'C-2024-0901', date: '2024-06-08', victim: 'Ramesh S.', type: 'UPI Fraud', amount: '₹1.2L', risk: 91, status: 'Active', district: 'T. Nagar' },
  { id: 'C-2024-0900', date: '2024-06-08', victim: 'Priya K.', type: 'ATM Skimming', amount: '₹45,000', risk: 78, status: 'Under Investigation', district: 'Anna Nagar' },
  { id: 'C-2024-0899', date: '2024-06-08', victim: 'Anand M.', type: 'Vishing', amount: '₹2.3L', risk: 63, status: 'Active', district: 'Vadapalani' },
  { id: 'C-2024-0898', date: '2024-06-07', victim: 'Sunitha R.', type: 'OTP Fraud', amount: '₹88,000', risk: 57, status: 'Escalated', district: 'Tambaram' },
  { id: 'C-2024-0897', date: '2024-06-07', victim: 'Vikram D.', type: 'Investment Scam', amount: '₹5.5L', risk: 44, status: 'Resolved', district: 'Porur' },
  { id: 'C-2024-0896', date: '2024-06-07', victim: 'Kavitha N.', type: 'Loan Fraud', amount: '₹1.8L', risk: 38, status: 'Active', district: 'Ambattur' },
];

const PREDICTIONS = [
  { location: 'T. Nagar ATM Cluster', lat: 13.0418, lng: 80.2341, confidence: 91, timeWindow: '10:00–12:00', atmsAtRisk: 6, severity: 'Critical', recommendation: 'Deploy Team Alpha immediately' },
  { location: 'Anna Nagar SBI', lat: 13.0850, lng: 80.2101, confidence: 78, timeWindow: '14:00–16:00', atmsAtRisk: 4, severity: 'High', recommendation: 'Station officer at branch' },
  { location: 'Vadapalani HDFC Row', lat: 13.0527, lng: 80.2120, confidence: 63, timeWindow: '11:00–13:00', atmsAtRisk: 3, severity: 'Medium', recommendation: 'Monitor via CCTV' },
  { location: 'Tambaram Cash Hub', lat: 12.9249, lng: 80.1000, confidence: 57, timeWindow: '15:00–17:00', atmsAtRisk: 2, severity: 'Medium', recommendation: 'Alert local PS' },
  { location: 'Porur Bus Terminus', lat: 13.0344, lng: 80.1571, confidence: 44, timeWindow: '09:00–11:00', atmsAtRisk: 2, severity: 'Low', recommendation: 'Low priority watch' },
  { location: 'Ambattur Industrial', lat: 13.1143, lng: 80.1548, confidence: 38, timeWindow: '16:00–18:00', atmsAtRisk: 1, severity: 'Low', recommendation: 'Routine patrol' },
];

const INTERVENTIONS = [
  { id: 'INT-089', location: 'T. Nagar ATM Cluster', team: 'Team Alpha (2 officers)', status: 'Active', time: '09:28 AM', outcome: 'On scene' },
  { id: 'INT-088', location: 'Anna Nagar SBI Branch', team: 'Team Beta (3 officers)', status: 'Active', time: '08:55 AM', outcome: 'Monitoring' },
  { id: 'INT-087', location: 'Vadapalani HDFC Row', team: 'Team Gamma (1 officer)', status: 'Active', time: '08:10 AM', outcome: 'Monitoring' },
  { id: 'INT-086', location: 'Tambaram Cash Hub', team: 'Team Delta (2 officers)', status: 'Complete', time: 'Yesterday', outcome: '1 arrested' },
  { id: 'INT-085', location: 'Porur Bus Terminus', team: 'Team Alpha', status: 'Complete', time: 'Yesterday', outcome: '₹42K seized' },
];

const NETWORK_CLUSTERS = [
  { id: 'A', accounts: 12, processed: '₹47L', risk: 'Critical', bank: 'HDFC / Axis', status: 'Frozen' },
  { id: 'B', accounts: 7, processed: '₹18L', risk: 'High', bank: 'SBI', status: 'Pending' },
  { id: 'C', accounts: 3, processed: '₹6L', risk: 'Medium', bank: 'Kotak', status: 'Active' },
  { id: 'D', accounts: 5, processed: '₹23L', risk: 'High', bank: 'Axis', status: 'Active' },
];

const INTEGRATIONS = [
  { name: 'NPCI Golden Hour API', desc: 'Account freeze requests for cybercrime victims', status: 'Connected', icon: 'building-columns' },
  { name: 'Axis Bank Freeze API', desc: 'Direct freeze integration with Axis Bank', status: 'Connected', icon: 'building-columns' },
  { name: 'SBI Cybercrime Portal', desc: 'State Bank of India escalation gateway', status: 'Connected', icon: 'building-columns' },
  { name: 'HDFC Bank API', desc: 'HDFC account freeze and investigation gateway', status: 'Degraded', icon: 'building-columns' },
  { name: 'SMS Gateway (Airtel)', desc: 'Field team and victim SMS alerts', status: 'Connected', icon: 'comment-sms' },
  { name: 'Tamil Nadu SIEM', desc: 'Security information & event management feed', status: 'Disconnected', icon: 'shield-halved' },
];

const ALERTS = [
  { id: 'AL-001', title: 'Critical: T. Nagar ATM cluster', desc: '91% withdrawal probability in 2h. 6 ATMs at risk.', time: '3 min ago', severity: 'Critical' },
  { id: 'AL-002', title: 'High: New mule network — 7 accounts', desc: 'Graph analysis links accounts to complaint #C-2024-0891.', time: '18 min ago', severity: 'High' },
  { id: 'AL-003', title: 'Info: Bank hold confirmed — Axis Adyar', desc: '₹2.3L frozen pending investigation. FIR filed at Adyar PS.', time: '41 min ago', severity: 'Info' },
  { id: 'AL-004', title: 'High: Vadapalani pattern match', desc: 'Transaction timestamps match known mule behavioral signature.', time: '1h ago', severity: 'High' },
];

module.exports = { USERS, COMPLAINTS, PREDICTIONS, INTERVENTIONS, NETWORK_CLUSTERS, INTEGRATIONS, ALERTS };
