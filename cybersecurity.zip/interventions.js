const router = require('express').Router();
const { getAll } = require('../controllers/interventionsController');
router.get('/', getAll);
module.exports = router;
