const router = require('express').Router();
const { getAll, freezeAccount } = require('../controllers/networkController');
router.get('/', getAll);
router.post('/freeze/:account', freezeAccount);
module.exports = router;
