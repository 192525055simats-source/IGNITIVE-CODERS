import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import styles from './Layout.module.css';

const NAV_ITEMS = [
  { group: 'Overview', items: [
    { id: 'dashboard', label: 'Dashboard', icon: 'fa-gauge-high', path: '/dashboard' },
    { id: 'alerts', label: 'Live Alerts', icon: 'fa-bell', path: '/alerts', badge: '4' },
  ]},
  { group: 'Operations', items: [
    { id: 'complaints', label: 'Complaints', icon: 'fa-file-lines', path: '/complaints', badge: '23', badgeBlue: true },
    { id: 'predictions', label: 'Predictions', icon: 'fa-brain', path: '/predictions' },
    { id: 'interventions', label: 'Interventions', icon: 'fa-shield-halved', path: '/interventions' },
  ]},
  { group: 'Intelligence', items: [
    { id: 'network', label: 'Mule Networks', icon: 'fa-diagram-project', path: '/network' },
    { id: 'integrations', label: 'Integrations', icon: 'fa-plug', path: '/integrations' },
  ]},
  { group: 'Admin', items: [
    { id: 'users', label: 'User Management', icon: 'fa-users', path: '/users' },
    { id: 'model-config', label: 'Model Config', icon: 'fa-sliders', path: '/model-config' },
  ]},
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => { logout(); navigate('/login'); };

  return (
    <div className={styles.app}>
      {/* Sidebar */}
      <aside className={styles.sidebar}>
        <div className={styles.brand}>
          <div className={styles.brandLogo}><i className="fa-solid fa-shield-halved" /></div>
          <div>
            <div className={styles.brandName}>CyberShield</div>
            <div className={styles.brandTag}>Predictive Analytics</div>
          </div>
        </div>

        <div className={styles.adminPill}>
          <i className="fa-solid fa-user-shield" />
          <div>
            <strong>{user?.name}</strong>
            <div style={{ fontSize: 10, color: '#8ab4d4', textTransform: 'capitalize' }}>{user?.role}</div>
          </div>
        </div>

        {NAV_ITEMS.map(group => (
          <div key={group.group} className={styles.navGroup}>
            <div className={styles.navGroupLabel}>{group.group}</div>
            {group.items.map(item => (
              <div
                key={item.id}
                className={`${styles.navItem} ${location.pathname === item.path ? styles.active : ''}`}
                onClick={() => navigate(item.path)}
              >
                <i className={`fa-solid ${item.icon}`} />
                {item.label}
                {item.badge && (
                  <span className={`${styles.navBadge} ${item.badgeBlue ? styles.blue : ''}`}>{item.badge}</span>
                )}
              </div>
            ))}
          </div>
        ))}

        <div className={styles.sidebarFooter}>
          <strong>CyberShield</strong> v1.0 · Tamil Nadu Police
        </div>
      </aside>

      {/* Main */}
      <div className={styles.main}>
        {/* Topbar */}
        <header className={styles.topbar}>
          <div className={styles.topbarLeft}>
            <div className={styles.breadcrumb}>
              CyberShield / <span style={{ color: '#1a2535', fontWeight: 500 }}>
                {location.pathname.replace('/', '').replace('-', ' ') || 'Dashboard'}
              </span>
            </div>
          </div>
          <div className={styles.topbarRight}>
            <div className={styles.liveBadge}>
              <span className={`${styles.liveDot} pulse`} />
              Live
            </div>
            <button className={styles.iconBtn} title="Notifications">
              <i className="fa-solid fa-bell" />
              <span className={styles.notifDot} />
            </button>
            <div className={styles.avatar} onClick={handleLogout} title="Logout">
              {user?.name?.charAt(0) || 'A'}
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className={styles.content}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
