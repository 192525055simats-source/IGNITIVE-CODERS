import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';
import Layout from './components/layout/Layout';
import LoginPage from './components/pages/LoginPage';
import DashboardPage from './components/pages/DashboardPage';
import ComplaintsPage from './components/pages/ComplaintsPage';
import PredictionsPage from './components/pages/PredictionsPage';
import InterventionsPage from './components/pages/InterventionsPage';
import NetworkPage from './components/pages/NetworkPage';
import AlertsPage from './components/pages/AlertsPage';
import UsersPage from './components/pages/UsersPage';
import IntegrationsPage from './components/pages/IntegrationsPage';
import ModelConfigPage from './components/pages/ModelConfigPage';

const PrivateRoute = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', color: '#8795a8' }}>Loading…</div>;
  return user ? children : <Navigate to="/login" replace />;
};

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route path="dashboard" element={<DashboardPage />} />
            <Route path="complaints" element={<ComplaintsPage />} />
            <Route path="predictions" element={<PredictionsPage />} />
            <Route path="interventions" element={<InterventionsPage />} />
            <Route path="network" element={<NetworkPage />} />
            <Route path="alerts" element={<AlertsPage />} />
            <Route path="users" element={<UsersPage />} />
            <Route path="integrations" element={<IntegrationsPage />} />
            <Route path="model-config" element={<ModelConfigPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
