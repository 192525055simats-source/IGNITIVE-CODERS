const { INTEGRATIONS } = require('../models/mockData');
const getAll = (req, res) => res.json({ success: true, data: INTEGRATIONS });
const test = (req, res) => res.json({ success: true, message: `Testing ${req.params.name}...`, latency: '142ms' });
module.exports = { getAll, test };
