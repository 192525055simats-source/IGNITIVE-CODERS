const { COMPLAINTS } = require('../models/mockData');

let complaints = [...COMPLAINTS];

const getAll = (req, res) => {
  const { status, search, page = 1, limit = 20 } = req.query;
  let result = [...complaints];
  if (status) result = result.filter(c => c.status === status);
  if (search) result = result.filter(c =>
    c.victim.toLowerCase().includes(search.toLowerCase()) ||
    c.id.toLowerCase().includes(search.toLowerCase()) ||
    c.type.toLowerCase().includes(search.toLowerCase())
  );
  const total = result.length;
  const start = (page - 1) * limit;
  result = result.slice(start, start + Number(limit));
  res.json({ success: true, data: result, total, page: Number(page), limit: Number(limit) });
};

const getById = (req, res) => {
  const c = complaints.find(c => c.id === req.params.id);
  if (!c) return res.status(404).json({ success: false, message: 'Complaint not found' });
  res.json({ success: true, data: c });
};

const create = (req, res) => {
  const { victim, type, amount, district, description } = req.body;
  if (!victim || !type || !amount)
    return res.status(400).json({ success: false, message: 'victim, type and amount are required' });

  const id = `C-2024-${String(Math.floor(Math.random() * 900) + 100)}`;
  const newComplaint = {
    id, date: new Date().toISOString().split('T')[0],
    victim, type, amount, district: district || 'Chennai',
    risk: Math.floor(Math.random() * 40 + 50),
    status: 'Active', description,
  };
  complaints.unshift(newComplaint);
  res.status(201).json({ success: true, data: newComplaint, message: `Complaint ${id} filed. ML pipeline triggered.` });
};

const updateStatus = (req, res) => {
  const idx = complaints.findIndex(c => c.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Complaint not found' });
  complaints[idx].status = req.body.status || complaints[idx].status;
  res.json({ success: true, data: complaints[idx] });
};

module.exports = { getAll, getById, create, updateStatus };
