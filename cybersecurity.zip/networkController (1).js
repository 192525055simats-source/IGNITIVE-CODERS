const { NETWORK_CLUSTERS } = require('../models/mockData');

const getAll = (req, res) => res.json({ success: true, data: NETWORK_CLUSTERS });

const freezeAccount = (req, res) => {
  res.json({ success: true, message: `Freeze request dispatched for account ${req.params.account}` });
};

module.exports = { getAll, freezeAccount };
