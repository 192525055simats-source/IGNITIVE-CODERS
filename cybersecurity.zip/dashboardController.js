const { COMPLAINTS, PREDICTIONS, INTERVENTIONS } = require('../models/mockData');

const getStats = (req, res) => {
  const active = COMPLAINTS.filter(c => c.status === 'Active').length;
  const critical = PREDICTIONS.filter(p => p.severity === 'Critical').length;
  const interventionsActive = INTERVENTIONS.filter(i => i.status === 'Active').length;

  res.json({
    success: true,
    data: {
      complaintsToday: 23,
      activeInterventions: interventionsActive,
      criticalHotspots: critical,
      fundsRecovered: '₹89L',
      modelAccuracy: '87%',
      avgResponseTime: '4.2 min',
      freezeSuccess: '91%',
      totalComplaints: COMPLAINTS.length,
      chartData: {
        daily: Array.from({ length: 30 }, (_, i) => ({
          day: i + 1,
          count: Math.floor(Math.random() * 18 + 5),
        })),
        recovery: [
          { month: 'Jan', amount: 42 }, { month: 'Feb', amount: 58 },
          { month: 'Mar', amount: 35 }, { month: 'Apr', amount: 71 },
          { month: 'May', amount: 64 }, { month: 'Jun', amount: 89 },
        ],
        accuracy: [
          { version: 'v3.0', location: 72, mule: 80, time: 65 },
          { version: 'v3.1', location: 75, mule: 82, time: 68 },
          { version: 'v3.2', location: 78, mule: 85, time: 70 },
          { version: 'v3.3', location: 80, mule: 86, time: 72 },
          { version: 'v3.4', location: 82, mule: 88, time: 74 },
          { version: 'v3.5', location: 84, mule: 90, time: 76 },
          { version: 'v3.6', location: 85, mule: 91, time: 78 },
          { version: 'v3.7', location: 87, mule: 92, time: 79 },
        ],
      },
    },
  });
};

module.exports = { getStats };
