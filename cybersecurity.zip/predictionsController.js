const { PREDICTIONS } = require('../models/mockData');

const getAll = (req, res) => {
  res.json({ success: true, data: PREDICTIONS });
};

const runPipeline = (req, res) => {
  // Simulate ML pipeline run
  setTimeout(() => {}, 0);
  res.json({
    success: true,
    message: 'ML pipeline triggered',
    estimatedCompletion: '60 seconds',
    jobId: `JOB-${Date.now()}`,
  });
};

module.exports = { getAll, runPipeline };
