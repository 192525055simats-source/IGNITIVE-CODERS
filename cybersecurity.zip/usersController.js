const { USERS } = require('../models/mockData');

const getAll = (req, res) => {
  if (req.user.role !== 'admin')
    return res.status(403).json({ success: false, message: 'Admin only' });
  const safe = USERS.map(({ password, ...u }) => u);
  res.json({ success: true, data: safe });
};

module.exports = { getAll };
