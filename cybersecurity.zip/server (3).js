require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const authRoutes = require('./routes/auth');
const dashboardRoutes = require('./routes/dashboard');
const complaintsRoutes = require('./routes/complaints');
const predictionsRoutes = require('./routes/predictions');
const interventionsRoutes = require('./routes/interventions');
const networkRoutes = require('./routes/network');
const usersRoutes = require('./routes/users');
const integrationsRoutes = require('./routes/integrations');
const alertsRoutes = require('./routes/alerts');

const { errorHandler } = require('./middleware/errorHandler');
const { authenticate } = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 5000;

// ── Security & Middleware ──────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true,
}));
app.use(morgan(process.env.NODE_ENV === 'development' ? 'dev' : 'combined'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Health Check ───────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), version: '1.0.0' });
});

// ── Public Routes ──────────────────────────────────────────────────
app.use('/api/auth', authRoutes);

// ── Protected Routes ───────────────────────────────────────────────
app.use('/api/dashboard', authenticate, dashboardRoutes);
app.use('/api/complaints', authenticate, complaintsRoutes);
app.use('/api/predictions', authenticate, predictionsRoutes);
app.use('/api/interventions', authenticate, interventionsRoutes);
app.use('/api/network', authenticate, networkRoutes);
app.use('/api/users', authenticate, usersRoutes);
app.use('/api/integrations', authenticate, integrationsRoutes);
app.use('/api/alerts', authenticate, alertsRoutes);

// ── 404 Handler ────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Route not found' });
});

// ── Error Handler ──────────────────────────────────────────────────
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`\n🛡️  CyberShield API running on http://localhost:${PORT}`);
  console.log(`   Environment : ${process.env.NODE_ENV || 'development'}`);
  console.log(`   Health check: http://localhost:${PORT}/api/health\n`);
});

module.exports = app;
