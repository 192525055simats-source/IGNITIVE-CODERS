const cron = require("node-cron");
const Complaint = require("../models/Complaint.model");
const Prediction = require("../models/Prediction.model");
const Alert = require("../models/Alert.model");
const mlClient = require("../services/mlClient.service");
const logger = require("../utils/logger");

/**
 * Every 5 minutes, re-score open complaints through the ML service and
 * persist fresh predictions — this is what keeps the "Threat Map" and
 * "Top Predicted Withdrawal Locations" cards feeling live without the
 * frontend having to poll the ML service directly.
 */
async function refreshOpenComplaintPredictions() {
  const openComplaints = await Complaint.findAll({ status: "new" });
  const investigating = await Complaint.findAll({ status: "investigating" });
  const targets = [...openComplaints, ...investigating];

  for (const complaint of targets) {
    const features = {
      complaint_id: complaint.id,
      fraud_type: complaint.fraud_type,
      amount: Number(complaint.amount),
      hour_of_day: new Date().getHours(),
      day_of_week: new Date().getDay(),
      mule_network_size: 0,
      network_centrality_score: 0,
      prior_complaints_in_area_7d: 0,
    };

    const prediction = await mlClient.getPrediction(features);
    if (prediction.degraded) continue;

    await Complaint.updateRiskScore(complaint.id, prediction.risk.risk_score);

    if (prediction.hotspots?.length) {
      await Prediction.bulkInsert(
        prediction.hotspots.map((h) => ({
          complaintId: complaint.id,
          locationName: h.location_name,
          latitude: h.latitude,
          longitude: h.longitude,
          probability: h.probability,
          windowStart: new Date(Date.now() + prediction.time_window.window_start_offset_minutes * 60000),
          windowEnd: new Date(Date.now() + prediction.time_window.window_end_offset_minutes * 60000),
          estimatedAmount: h.estimated_amount,
          modelVersion: prediction.model_versions?.hotspot,
        }))
      );

      const top = prediction.hotspots[0];
      if (top.probability >= 80) {
        await Alert.create({
          title: `Critical: ${top.location_name}`,
          description: `${top.probability}% withdrawal probability predicted by refreshed model run.`,
          severity: "critical",
          complaintId: complaint.id,
        });
      }
    }
  }

  if (targets.length) {
    logger.info(`Refreshed predictions for ${targets.length} open complaint(s)`);
  }
}

function startPredictionRefreshJob() {
  // every 5 minutes
  cron.schedule("*/5 * * * *", () => {
    refreshOpenComplaintPredictions().catch((err) =>
      logger.error(`refreshPredictions job failed: ${err.message}`)
    );
  });
  logger.info("Prediction refresh job scheduled (every 5 minutes)");
}

module.exports = { startPredictionRefreshJob, refreshOpenComplaintPredictions };
