const { ALERTS } = require('../models/mockData');
const getAll = (req, res) => res.json({ success: true, data: ALERTS });
module.exports = { getAll };
